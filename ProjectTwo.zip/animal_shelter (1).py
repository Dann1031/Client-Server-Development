from pymongo import MongoClient
from pymongo.errors import PyMongoError
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self):
        USER = 'aacuser'
        PASS = 'Danny1031!'
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 34241
        DB = 'AAC'
        COL = 'animals'

        self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}')
        self.database = self.client[DB]
        self.collection = self.database[COL]

    def create(self, data):
        """Inserts a document into the collection"""
        if data:
            try:
                self.collection.insert_one(data)
                return True
            except Exception as e:
                print(f"An error occurred while inserting: {e}")
                return False
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    def read(self, query):
        """Queries for documents based on key/value pair"""
        try:
            result = list(self.collection.find(query))
            return result
        except Exception as e:
            print(f"An error occurred during read: {e}")
            return []

    def update(self, query, new_values):
        """Update matching document(s)"""
        try:
            result = self.collection.update_many(query, {"$set": new_values})
            return result.modified_count
        except PyMongoError as e:
            print("An error occurred while updating:", e)
            return 0

    def delete(self, query):
        """Delete matching document(s)"""
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except PyMongoError as e:
            print("An error occurred while deleting:", e)
            return 0
